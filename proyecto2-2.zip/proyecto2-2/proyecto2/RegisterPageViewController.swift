//
//  RegisterPageViewController.swift
//  proyecto2
//
//  Created by Jose alberto on 19/10/18.
//  Copyright © 2018 Jose alberto. All rights reserved.
//

import UIKit

class RegisterPageViewController: UIViewController {

    @IBOutlet weak var userEmailTextField: UITextField!
    @IBOutlet weak var userPasswordTextField: UITextField!
    @IBOutlet weak var repeatPasswordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func registerButtonTapped(_ sender: Any) {
        let userEmail = userEmailTextField.text
        var userPassword = userPasswordTextField.text
        let userRepeatPassword = repeatPasswordTextField.text
        
        if((userEmail?.isEmpty)! || (userPassword?.isEmpty)! || (userPassword?.isEmpty)!)
        {
            displayMyAlertMessage(userMessage: "Allfields are required")
            return
        }
        if(userPassword! == userRepeatPassword!)
        {
            displayMyAlertMessage(userMessage: "Passwords don't match");            return
        }
        
        UserDefaults.standard.set(userEmail, forKey:"userEmail")
        UserDefaults.standard.set(userPassword, forKey:"userPassword")
        UserDefaults.standard.synchronize()
        
        var myalert = UIAlertController(title:"Alert", message: "Registration is suscessful. Thank you!", preferredStyle: UIAlertControllerStyle.alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default){ action in
            self.dismiss(animated: true, completion: nil)
            
        }
        myalert.addAction(okAction)
        self.present(myalert, animated: true, completion: nil)
        
    }
    
    func displayMyAlertMessage(userMessage: String)
    {
        var myalert = UIAlertController(title:"Alert", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        
        myalert.addAction(okAction)
        
        self.present(myalert, animated: true, completion: nil)
    }
    

}






